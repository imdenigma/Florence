import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.*;
import java.awt.*;
//import java.io.File;
//import java.awt.image.BufferedImage;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//import javax.imageio.ImageIO;
import java.util.Properties;
import java.sql.*;
import java.net.URL;

@SuppressWarnings("serial")
class SlidePane extends JPanel {

    private long startTime = -1;
    private int runTime = 1000;
    private int startX;
    private int targetX;
    private boolean slideIn = false;
    private Timer slideTimer;

    public SlidePane() {
        setBackground(new Color(243, 156, 18));
        setBorder(new LineBorder(Color.PINK, 2, true));
        setLocation(-getPreferredSize().width, 0);
        slideTimer = new Timer(1, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                long diff = System.currentTimeMillis() - startTime;
                double progress = (double)diff / (double)runTime;
                if (progress >= 1d) {
                    progress = 1d;
                    slideTimer.stop();
                    startTime = -1;
                }

                Container parent = getParent();
                int height = parent.getHeight();
                setSize(getPreferredSize().width, height);

                int x = calculateProgress(startX, targetX, progress);
                setLocation(x, 0);
                revalidate();
                repaint();
            }
        });
    }
    protected int calculateProgress(int startValue, int endValue, double fraction) {

        int value = 0;
        int distance = endValue - startValue;
        value = (int) Math.round((double) distance * fraction);
        value += startValue;

        return value;

    }
    @Override
    public Dimension getPreferredSize() {
        return new Dimension(260, 600);
    }
    public void slide() {

        slideTimer.stop();
        startTime = System.currentTimeMillis();

        slideIn = !slideIn;
        startX = getX();
        targetX = 0;
        if (!slideIn) {
            targetX = -getPreferredSize().width;
        }
        slideTimer.start();
    }
}

class ChatBot
{
	static JFrame f, fh;
	static JPanel j, j1, js, ji, jp, jp1, jp2, jp3, jp4, jp5, SPanel, MPanel;
	static JTextArea t, T, T2, T3, T4, T5, T6;
	static JButton b, MButton;
	static JButton B[] = new JButton[7], OP[] = new JButton[5];
	static CardLayout card;
	static int c1=0, c2=85, k, clk=1, clk2=1, clk3=1, clk4=1, clk5=1;
	static String store[]=new String[4], SM2[]=new String[8], SM3[]=new String[8], SM4[]=new String[8], SM5[]=new String[8], SM6[]=new String[8];
	static byte hold1, hold2, hold3, hold4, hold5, hold6;
	static char flg0, flg2, flg3, isRmv='\0', flg='T', hld='A', flg4, flg5, flg6;
	private SlidePane glass = new SlidePane();
	ChatBot()
	{	 
		JFrame.setDefaultLookAndFeelDecorated(false);
		f = new JFrame();
		f.setTitle("Medical Service Application");
		ImageIcon img = new ImageIcon("Florence.png");
		f.setIconImage(img.getImage().getScaledInstance(256, 256, Image.SCALE_SMOOTH));
		
		JPanel support = new JPanel(null);
		j = new JPanel()/* First Panel */;	j1 = new JPanel()/* For Text Area*/;	js = new JPanel()/* Support Panel inside (j1)*/;
		SPanel = new JPanel();		MPanel = new JPanel();
		b = new JButton("<html><body><h1>"
				+ "<font face=consolas size=7>></font>"
				+ "</h1></body></html>");
		b.setHorizontalAlignment(JButton.CENTER);
		b.setPreferredSize(new Dimension(80, 32));
		b.setBackground(new Color(25, 181, 254));
		b.setForeground(Color.WHITE);
		
		MButton = new JButton(">");
		MButton.setFont(new Font("Consolas", Font.BOLD, 30));
		MButton.setHorizontalAlignment(SwingConstants.CENTER);
		MButton.setVerticalAlignment(SwingConstants.CENTER);
		MButton.setPreferredSize(new Dimension(45, 18));
		MButton.setBackground(new Color(219, 10, 10));
		MButton.setForeground(Color.WHITE);
		MButton.setBorder(null);
		
		MButton.addActionListener
		(
			new ActionListener() 
			{
				public void actionPerformed(ActionEvent e) 
				{
					glass.slide();
				}
			}
		);
		
		JLabel write = new JLabel("Choose Any Option");
		write.setFont(new Font("Consolas", Font.BOLD, 18));
		write.setForeground(Color.WHITE);
		MPanel.setLayout(new BorderLayout());
		MPanel.setPreferredSize(new Dimension(250, 40));
		MPanel.setBackground(new Color(219, 10, 10));
		MPanel.setBorder(new EmptyBorder(11, 0, 5, 28));
		MPanel.add(MButton, BorderLayout.WEST);	
		MPanel.add(write, BorderLayout.EAST);
		
		t = new JTextArea("Write Something....", 1, 35);
		t.setLineWrap(true);
		t.setFont(Font.decode("Ubuntu-PLAIN-20"));
		t.setBackground(new Color(210, 215, 211));
		t.setForeground(Color.BLACK);
		
		j.setBackground(new Color(246, 36, 89));
		j1.setBackground(new Color(46, 49, 49));
		js.setBackground(new Color(255, 246, 143));
		
		/** To Set The Fixed Size of Each Panel **/
		j.setPreferredSize(new Dimension(250, 600));
		j1.setPreferredSize(new Dimension(750, 60));
		SPanel.setPreferredSize(new Dimension(750, 550));
		js.setSize(new Dimension(750, 600));
		
		/** For Text Area Operation **/
		JScrollPane p = new JScrollPane(t, JScrollPane.VERTICAL_SCROLLBAR_NEVER, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		j1.setBorder(new EmptyBorder(9, 20, 0, 0));
		j1.add(p);
		j1.add(Box.createRigidArea(new Dimension(20, 0)));
		j1.add(b);
		
		card = new CardLayout();
		SPanel.setLayout(card);
		js.setLayout(new BorderLayout());
		js.add(j1, BorderLayout.SOUTH);
		
		support.setOpaque(false);
		support.add(glass);
		
		j.add(MPanel);
		
		f.getContentPane().setLayout(new BoxLayout(f.getContentPane(), BoxLayout.X_AXIS));
		f.setGlassPane(support);
		support.setVisible(true);
		f.add(j);
		f.add(js);
		
		f.setSize(1000, 600);
		f.getContentPane().setBackground(Color.WHITE);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);
		f.setResizable(true);
		f.setLocationRelativeTo(null);
	}
	static void Introduce_Part()
	{
		ji = new JPanel();
		ji.setPreferredSize(new Dimension(750, 550));
		ji.setBackground(new Color(247, 202, 24));
		JLabel L = new JLabel("Click Any Option", SwingConstants.CENTER);
		L.setFont(new Font("Century Schoolbook", Font.BOLD, 35));
		
		L.setBackground(Color.BLUE);
		L.setForeground(Color.BLUE);
	
		// 275, 375, 275, 0
		ji.setLayout(new BorderLayout());
		ji.add(L, BorderLayout.CENTER);
		js.add(ji, BorderLayout.CENTER);
	}
	static void Appearance()
	{
		Window jw = new Window(f);
		jw.setBackground(new Color(211, 28, 91));
		
		JLabel L = new JLabel("F l o r e n c e", SwingConstants.CENTER);
		L.setFont(new Font("Century Schoolbook", Font.ITALIC, 50));
		L.setForeground(Color.WHITE/**new Color(31, 58, 147)**/);
		
		try 
		{
			jw.add(L);
			jw.setSize(new Dimension(500, 300));
			jw.setLocationRelativeTo(null);
			jw.setVisible(true);
		Thread.sleep(10000);
		jw.setVisible(false);
		}catch(Exception e) {
		System.out.println(e.getMessage());
		}
	}
	static void MessageBox_1() 
	{
	jp = new JPanel();
	jp.setPreferredSize(new Dimension(750, 550));
	
	T = new JTextArea();
	T.setText("ChatBot--> Hello I am Florence! How can I help you?" + '\n');
	T.setFont(new Font("Roboto", Font.BOLD, 20));
	T.setForeground(Color.BLACK);
	T.setBackground(new Color(255, 246, 143));
	T.setEditable(false);
	
	JScrollPane b2 = new JScrollPane(T);
	//b2.getViewport().getView().setBackground(new Color(255, 246, 143));
	b2.setWheelScrollingEnabled(true);
	b2.setVisible(true);

	jp.setLayout(new GridLayout(1,1));
	jp.setBackground(new Color(255, 246, 143));
	jp.add(b2);
	jp.setVisible(true);
	
	t.setText("Write Something...");
		b.addActionListener
		(
		new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				T.setLineWrap(true);
				T.setWrapStyleWord(true);
				int kp1=3;
				String Semergency[] = new String[2];
				String Q1[] = {
						"Is it an emergency or do you want an appointment?",
						"Should we call an Ambulance?",
						"Please allow Florence to access Location for finding nearby hospitals?",
						"Do you want to select a time or should I select a preferable time for you?",
						"When do you usually stay free?"
				};
				String arg1[]={"Emergency", "Appointment"}, 
					   arg2[]={"Yes", "No"},
					   select[] = {"I select", "User select", "\0"};
				if(c1==0) 
				{
					T.append("You--> "+t.getText()+'\n'+'\n'+"ChatBot--> "+Q1[0]+'\n'
							+ "1.Emergency"+'\n'+"2.Appointment"+ '\n');
				c1=1;
				}else if(c1==1) {
					if(t.getText().equals("1")) {
						store[0]=arg1[0];	c1=2;
					}
					else if(t.getText().equals("2")) {
						store[0]=arg1[1];	hld='T';
					}else {
						for(int i=0; i<arg1.length; i+=1) {
							if(arg1[i]==t.getText()) {
								store[0]=arg1[i];
							}
						}
					}
					if(hld=='T'||store[0]=="Appointment") {
						hld='D';	c1=4;
					}
				}
				if(c1==2) /** Emergency **/
				{
					if(hld=='A') {
						T.append("You--> "+t.getText()+'\n'+'\n'+"ChatBot--> "+Q1[1]+'\n'+'\n');
					hld='B';
					}else if(hld=='B') {
						if(t.getText().equals("yes") || t.getText().equals("Yes"))
							Semergency[0]=t.getText();
						else
							Semergency[0]=t.getText();
						T.append("You--> "+t.getText()+'\n'+'\n'+"ChatBot--> Provide your location:"+'\n'+'\n');
					hld='C';
					}else if(hld=='C') {
						Semergency[1]=t.getText();
						T.append("You--> "+t.getText()+'\n'+'\n'+"ChatBot--> An ambulance will try to arrive immediately at your place ASAP!!");
					c1=3;	flg0='#';
					}
				}else if(c1==4) /** Appointment **/
				{
					if(hld=='D') {
						T.append("You--> "+t.getText()+'\n'+'\n'+"ChatBot--> "+Q1[2]+'\n'
								+ "1.Yes"+ '\n'+ "2.No"+ '\n');
					hld='E';	c2=85;
					}else if(hld=='E'||c2==85) 
					{
						if(t.getText().equals("1"))
							store[1]=arg2[0];
						else if(t.getText().equals("2"))
							store[1]=arg2[1];
						else {
							for(int i=0; i<arg2.length; i+=1)
								if(t.getText().equals(arg2[i]))
									store[1]=arg2[i];
						}
						
						T.append("You--> "+t.getText()+'\n'+'\n'+"ChatBot--> "+Q1[3]+'\n'
								+"Please, Insert Numeric Value For This Case?"+'\n'
								+ "1.I select"+'\n'+"2.User select" +'\n'+'\n');
					hld='F';	c2=87;
					}else if(hld=='F'||c2==87) 
					{
						if(t.getText()=="1")
							kp1 = Integer.parseInt(t.getText());
						else if(t.getText()=="2")
							kp1 = Integer.parseInt(t.getText());
					c2=89;
					}
					hld='G';
					}else if(select[kp1-1]=="I select") {
						T.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> According to your Location, and your symptoms we have found 5 Doctors"+'\n'
								+"1. Dr. Alex,The Public Hospital (16:00-20:00)"+'\n'
								+"2. Dr. Khan,Healthcare Hospital (10:00-15:00)"+'\n'
								+"3. Dr. Barry,The Public Hospital (17:00-21:00)"+'\n'
								+"4. Dr. Hoppins,City Hospital (14:00-18:00)"+'\n'
								+"5. Dr. Singh,The Emergancycare Hospital (11:00-14:00)"+'\n'
								+"Enter which Doctor You Want?"+'\n');
					hld='K';	
					}else if(select[kp1-1]=="User select") {
						if(hld=='G') {
							T.append("You--> "+t.getText()+'\n'+'\n'+"ChatBot--> "+Q1[4]+'\n'+'\n');
						hld='H';
						}else if(hld=='H') {
							store[2]=t.getText();
							T.append("You--> "+t.getText()+'\n'+'\n'+"ChatBot--> These are the perfect option for you choose an option!"+'\n'
									+"1. Dr. Alex,The Public Hospital (16:00-20:00)"+'\n'
									+"2. Dr. Barry,The Public Hospital (17:00-21:00)"+'\n'
									+"3. Dr. Hoppins,City Hospital (14:00-18:00)"+'\n'
									+"Enter which doctor you want?"
									);
						}
					}else if(hld=='K') {
						T.append("You--> "+t.getText()+'\n'+'\n'+"ChatBot--> Thank you, your appointment is confirmed!");
					c1=5;	flg0='#';
					}
				}
			}
		);
	SPanel.add(jp, "S1");
	}
	static void MessageBox_2() 
	{
		jp1 = new JPanel();
		jp1.setPreferredSize(new Dimension(750, 550));
		
		T2 = new JTextArea();
		T2.setText("ChatBot--> Hello I am Florence! Do you have any leg problem?" + '\n');
		T2.setFont(new Font("Roboto", Font.BOLD, 20));
		T2.setForeground(Color.BLACK);
		T2.setBackground(new Color(255, 246, 143));
		T2.setEditable(false);
		
		JScrollPane b3 = new JScrollPane(T2);
		//b2.getViewport().getView().setBackground(new Color(255, 246, 143));
		b3.setWheelScrollingEnabled(true);
		b3.setVisible(true);

		jp1.setLayout(new GridLayout(1,1));
		jp1.setBackground(new Color(255, 246, 143));
		jp1.add(b3);
		jp1.setVisible(true);

			b.addActionListener
			(
			new ActionListener() 
			{
				public void actionPerformed(ActionEvent e) 
				{
					T2.setLineWrap(true);
					T2.setWrapStyleWord(true);
					String hlp1[] = {"Above thigh", "Below Thigh", "Calf Muscles", "Ankle", "The whole Leg"};
					String hlp2[] = {"Few Hours", "Few Days", "Long Time", "Reccently"};
					String yesno[] = {"Yes", "No"};
					if(k==1) 
					{
						T2.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Where is it paining?"+'\n'
								+"1.Above thigh" +'\n'+"2.Below Thigh"+'\n'+"3.Calf Muscles"+'\n'+"4.Ankle"+'\n'+"5.The whole Leg"+'\n'+'\n');
					t.setText("");
					k+=1;
					}else if(k==2) {
						for(int k=0; k<hlp1.length; k+=1)
							if(k==(Integer.parseInt(t.getText())-1))
								SM2[0]=hlp1[k];
						
						T2.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Since how long is it paining?"+'\n'
								+"1.Few Hours"+'\n'+"2.Few Days"+'\n'+"3.Long Time"+'\n'+"4.Recently"+'\n'+'\n');
						t.setText("");
					k+=1;
					}else if(k==3) {
						for(int k=0; k<hlp2.length; k+=1)
							if(k==(Integer.parseInt(t.getText())-1))
								SM2[1]=hlp2[k];
						
						T2.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Does it hurt while you move your leg?"+'\n'
								+"1.Yes"+'\n'+"2.No"+'\n'+'\n');
						t.setText("");
					k+=1;
					}else if(k==4) {
						for(int y=0; y<yesno.length; y+=1)
							if(y==(Integer.parseInt(t.getText())-1))
								SM2[2]=yesno[y];
						
						T2.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Try touching the part where it is paining. Does it hurt?"+'\n'
								+"1.Yes"+'\n'+"2.No"+'\n'+'\n');
						t.setText("");
					k+=1;
					}else if(k==5) {
						for(int y=0; y<yesno.length; y+=1)
							if(y==(Integer.parseInt(t.getText())-1))
								SM2[3]=yesno[y];
						
						T2.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Did You try any Medications?"+'\n'
								+"1.Yes"+'\n'+"2.No"+'\n'+'\n');
						t.setText("");
					k+=1;
					}else if(k==6) {
						for(int y=0; y<yesno.length; y+=1)
							if(y==(Integer.parseInt(t.getText())-1))
								SM2[4]=yesno[y];
						
						T2.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Is it Swollen?"+'\n'
								+"1.Yes"+'\n'+"2.No"+'\n'+'\n');
						t.setText("");
					k+=1;
					}else if(k==7) {
						for(int y=0; y<yesno.length; y+=1)
							if(y==(Integer.parseInt(t.getText())-1))
								SM2[5]=yesno[y];
						
						T2.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Did you get hurt there recently?"+'\n'
								+"1.Yes"+'\n'+"2.No"+'\n'+'\n');
						t.setText("");
					k+=1;
					}else if(k==8) {
						for(int y=0; y<yesno.length; y+=1)
							if(y==(Integer.parseInt(t.getText())-1))
								SM2[6]=yesno[y];
						
						T2.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Did you do any leg workout recently?"+'\n'
								+"1.Yes"+'\n'+"2.No"+'\n'+'\n');
						t.setText("");
					k+=1;
					}else{
						for(int y=0; y<yesno.length; y+=1)
							if(y==(Integer.parseInt(t.getText())-1))
								SM2[7]=yesno[y];
						
						T2.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Thank you for providing information");
					flg2='#';
					}
				}
			}
			);
	SPanel.add(jp1, "S2");
	}
	static void MessageBox_3() 
	{
		jp2 = new JPanel();
		jp2.setPreferredSize(new Dimension(750, 550));
		
		T3 = new JTextArea();
		T3.setText("ChatBot--> Hello I am Florence! Do you have any problem in hand?" + '\n');
		T3.setFont(new Font("Roboto", Font.BOLD, 20));
		T3.setForeground(Color.BLACK);
		T3.setBackground(new Color(255, 246, 143));
		T3.setEditable(false);
		
		JScrollPane b4 = new JScrollPane(T3);
		//b2.getViewport().getView().setBackground(new Color(255, 246, 143));
		b4.setWheelScrollingEnabled(true);
		b4.setVisible(true);

		jp2.setLayout(new GridLayout(1,1));
		jp2.setBackground(new Color(255, 246, 143));
		jp2.add(b4);
		jp2.setVisible(true);

			b.addActionListener
			(
			new ActionListener() 
			{
				public void actionPerformed(ActionEvent e) 
				{
					T3.setLineWrap(true);
					T3.setWrapStyleWord(true);
					String s1[] = {"Below Elbow", "Forearms", "Wrist", "Elbow"};
					String s2[] = {"Few Hours", "Few Days", "Long Time"};
					String yesNo[] = {"Yes", "No"};
					if(clk2==1) 
					{
						T3.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Where is it paining?"+'\n'
								+"1.Below Elbow" +'\n'+"2.Forearms"+'\n'+"3.Wrist"+'\n'+"4.Elbow"+'\n'+'\n');
						t.setText("");	
					clk2+=1;
					}else if(clk2==2) {
						for(int k=0; k<s1.length; k+=1)
							if(k==(Integer.parseInt(t.getText())-1))
								SM3[0]=s1[k];
						
						T3.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Since how long is it paining?"+'\n'
								+"1.Few Hours"+'\n'+"2.Few Days"+'\n'+"3.Long Time"+'\n'+'\n');
						t.setText("");
					clk2+=1;
					}else if(clk2==3) {
						for(int k=0; k<s1.length; k+=1)
							if(k==(Integer.parseInt(t.getText())-1))
								SM3[1]=s2[k];
						
						T3.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Does it hurt while you move your hands??"+'\n'
								+"1.Yes"+'\n'+"2.No"+'\n'+'\n');
						t.setText("");
					clk2+=1;
					}else if(clk2==4) {
						for(int k=0; k<s1.length; k+=1)
							if(k==(Integer.parseInt(t.getText())-1))
								SM3[2]=yesNo[k];
						
						T3.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Try bending your arms. Does it hurt?"+'\n'
								+"1.Yes"+'\n'+"2.No"+'\n'+'\n');
						t.setText("");
					clk2+=1;
					}else if(clk2==5) {
						for(int k=0; k<s1.length; k+=1)
							if(k==(Integer.parseInt(t.getText())-1))
								SM3[3]=yesNo[k];
						
						T3.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Did You try any Medications?"+'\n'
								+"1.Yes"+'\n'+"2.No"+'\n'+'\n');
						t.setText("");
					clk2+=1;
					}else if(clk2==6) {
						for(int k=0; k<s1.length; k+=1)
							if(k==(Integer.parseInt(t.getText())-1))
								SM3[4]=yesNo[k];
						
						T3.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Did you carry any heavyweights lately?"+'\n'
								+"1.Yes"+'\n'+"2.No"+'\n'+'\n');
						t.setText("");
					clk2+=1;
					}else if(clk2==7) {
						for(int k=0; k<s1.length; k+=1)
							if(k==(Integer.parseInt(t.getText())-1))
								SM3[5]=yesNo[k];
						
						T3.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Did you ever get hurt on your head? If yes then how long ago?"+'\n'+'\n');
						t.setText("");
					clk2+=1;
					}else if(clk2==8) {
						SM3[6]=t.getText();
						
						T3.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Is it bleeding?"+'\n'
								+"1.Yes"+'\n'+"2.No"+'\n'+'\n');
						t.setText("");
					clk2+=1;
					}else {
						for(int k=0; k<s1.length; k+=1)
							if(k==(Integer.parseInt(t.getText())-1))
								SM3[7]=yesNo[k];
						
						T3.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Thank you for providing information");
					flg3='#';
					}
				}
			}
			);
	SPanel.add(jp2, "S3");
	}
	static void MessageBox_4() 
	{
		jp3 = new JPanel();
		jp3.setPreferredSize(new Dimension(750, 550));
		
		T4 = new JTextArea();
		T4.setText("ChatBot--> Hello I am Florence! Do you have any problem in chest?" + '\n');
		T4.setFont(new Font("Roboto", Font.BOLD, 20));
		T4.setForeground(Color.BLACK);
		T4.setBackground(new Color(255, 246, 143));
		T4.setEditable(false);
		
		JScrollPane b5 = new JScrollPane(T4);
		//b2.getViewport().getView().setBackground(new Color(255, 246, 143));
		b5.setWheelScrollingEnabled(true);
		b5.setVisible(true);

		jp3.setLayout(new GridLayout(1,1));
		jp3.setBackground(new Color(255, 246, 143));
		jp3.add(b5);
		jp3.setVisible(true);

			b.addActionListener
			(
			new ActionListener() 
			{
				public void actionPerformed(ActionEvent e) 
				{
					T4.setLineWrap(true);
					T4.setWrapStyleWord(true);
					String str1[] = {"Centre of the chest", "Left side", "Right Side", "Lower Side of the chest"};
					String str2[] = {"Few Hours", "Few Days", "Long Time", "Recently"};
					String yesNO[] = {"Yes", "No"};
					if(clk3==1) 
					{
						T4.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Where is it paining?"+'\n'
								+"1.Centre of the chest"+'\n'+"2.Left side"+'\n'+"3.Right Side"+'\n'+"4.Lower Side of the chest"+'\n'+'\n');
						t.setText("");	
					clk3+=1;
					}else if(clk3==2) {
						for(int u=0; u<str1.length; u+=1)
							if(u==(Integer.parseInt(t.getText())-1))
								SM4[0]=str1[u];
						
						T4.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Since how long is it paining?"+'\n'
								+"1.Few Hours"+'\n'+"2.Few Days"+'\n'+"3.Long Time"+'\n'+"4.Recently"+'\n'+'\n');
						t.setText("");
					clk3+=1;
					}else if(clk3==3) {
						for(int u=0; u<str2.length; u+=1)
							if(u==(Integer.parseInt(t.getText())-1))
								SM4[1]=str2[u];
						
						T4.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Does it hurt while you move?"+'\n'
								+"1.Yes"+'\n'+"2.No"+'\n'+'\n');
						t.setText("");
					clk3+=1;
					}else if(clk3==4) {
						for(int u=0; u<yesNO.length; u+=1)
							if(u==(Integer.parseInt(t.getText())-1))
								SM4[2]=yesNO[u];
						
						T4.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Try getting up. Does it hurt?"+'\n'
								+"1.Yes"+'\n'+"2.No"+'\n'+'\n');
						t.setText("");
					clk3+=1;
					}else if(clk3==5) {
						for(int u=0; u<yesNO.length; u+=1)
							if(u==(Integer.parseInt(t.getText())-1))
								SM4[3]=yesNO[u];
						
						T4.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Did You try any Medications?"+'\n'
								+"1.Yes"+'\n'+"2.No"+'\n'+'\n');
						t.setText("");
					clk3+=1;
					}else if(clk3==6) {
						for(int u=0; u<yesNO.length; u+=1)
							if(u==(Integer.parseInt(t.getText())-1))
								SM4[4]=yesNO[u];
						
						T4.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Do you drink water on a regular basis??"+'\n'
								+"1.Yes"+'\n'+"2.No"+'\n'+'\n');
						t.setText("");
					clk3+=1;
					}else if(clk3==7) {
						for(int u=0; u<yesNO.length; u+=1)
							if(u==(Integer.parseInt(t.getText())-1))
								SM4[5]=yesNO[u];
						
						T4.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Did you ever had any heart related disease?"+'\n'+'\n');
						t.setText("");
					clk3+=1;
					}else if(clk3==8) {
						SM4[6]=t.getText();
						
						T4.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Is it bleeding?"+'\n'
								+"1.Yes"+'\n'+"2.No"+'\n'+'\n');
						t.setText("");
					clk3+=1;
					}else {
						for(int u=0; u<yesNO.length; u+=1)
							if(u==(Integer.parseInt(t.getText())-1))
								SM4[7]=yesNO[u];
						
						T4.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Thank you for providing information");
					flg4='#';
					}
				}
			}
			);
	SPanel.add(jp3, "S4");
	}
	static void MessageBox_5() 
	{
		jp4 = new JPanel();
		jp4.setPreferredSize(new Dimension(750, 550));
		
		T5 = new JTextArea();
		T5.setText("ChatBot--> Hello I am Florence! Do you have any problem in head?" + '\n');
		T5.setFont(new Font("Roboto", Font.BOLD, 20));
		T5.setForeground(Color.BLACK);
		T5.setBackground(new Color(255, 246, 143));
		T5.setEditable(false);
		
		JScrollPane b5 = new JScrollPane(T5);
		//b2.getViewport().getView().setBackground(new Color(255, 246, 143));
		b5.setWheelScrollingEnabled(true);
		b5.setVisible(true);

		jp4.setLayout(new GridLayout(1,1));
		jp4.setBackground(new Color(255, 246, 143));
		jp4.add(b5);
		jp4.setVisible(true);

			b.addActionListener
			(
			new ActionListener() 
			{
				public void actionPerformed(ActionEvent e) 
				{
					T5.setLineWrap(true);
					T5.setWrapStyleWord(true);
					String h1[] = {"Forehead", "Inside the head", "Full head"};
					String h2[] = {"Few Hours", "Few Days", "Long Time", "Recently"};
					String yesno[] = {"Yes", "No"};
					if(clk4==1) 
					{
						T5.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Where is it paining?"+'\n'
								+"1.Forehead"+'\n'+"2.Inside the head"+'\n'+"3.Full head"+'\n'+'\n');
						t.setText("");	
					clk4+=1;
					}else if(clk4==2) {
						for(int g=0; g<h1.length; g+=1)
							if(g==(Integer.parseInt(t.getText())-1))
								SM5[0]=h1[g];
						
						T5.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Since how long is it paining?"+'\n'
								+"1.Few Hours"+'\n'+"2.Few Days"+'\n'+"3.Long Time"+'\n'+"4.Recently"+'\n'+'\n');
						t.setText("");
					clk4+=1;
					}else if(clk4==3) {
						for(int g=0; g<h2.length; g+=1)
							if(g==(Integer.parseInt(t.getText())-1))
								SM5[1]=h2[g];
						
						T5.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Does it hurt while you move?"+'\n'
								+"1.Yes"+'\n'+"2.No"+'\n'+'\n');
						t.setText("");
					clk4+=1;
					}else if(clk4==4) {
						for(int g=0; g<yesno.length; g+=1)
							if(g==(Integer.parseInt(t.getText())-1))
								SM5[2]=yesno[g];
						
						T5.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Try Moving your head slowly from left to right. Does it hurt?"+'\n'
								+"1.Yes"+'\n'+"2.No"+'\n'+'\n');
						t.setText("");
					clk4+=1;
					}else if(clk4==5) {
						for(int g=0; g<yesno.length; g+=1)
							if(g==(Integer.parseInt(t.getText())-1))
								SM5[3]=yesno[g];
						
						T5.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Did You try any Medications?"+'\n'
								+"1.Yes"+'\n'+"2.No"+'\n'+'\n');
						t.setText("");
					clk4+=1;
					}else if(clk4==6) {
						for(int g=0; g<yesno.length; g+=1)
							if(g==(Integer.parseInt(t.getText())-1))
								SM5[4]=yesno[g];
						
						T5.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Are you in stress lately?"+'\n'
								+"1.Yes"+'\n'+"2.No"+'\n'+'\n');
						t.setText("");
					clk4+=1;
					}else if(clk4==7) {
						for(int g=0; g<yesno.length; g+=1)
							if(g==(Integer.parseInt(t.getText())-1))
								SM5[5]=yesno[g];
						
						T5.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Did you ever get hurt on your head? If yes then how long ago?"+'\n'+'\n');
						t.setText("");
					clk4+=1;
					}else if(clk4==8) {
						SM5[6]=t.getText();
						
						T5.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Is it bleeding?"+'\n'
								+"1.Yes"+'\n'+"2.No"+'\n'+'\n');
						t.setText("");
					clk4+=1;
					}else {
						for(int g=0; g<yesno.length; g+=1)
							if(g==(Integer.parseInt(t.getText())-1))
								SM5[7]=yesno[g];
						T5.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Thank you for providing information");
					flg5='#';
					}
				}
			}
			);
	SPanel.add(jp4, "S5");
	}
	static void MessageBox_6() 
	{
		jp5 = new JPanel();
		jp5.setPreferredSize(new Dimension(750, 550));
		
		T6 = new JTextArea();
		T6.setText("ChatBot--> Hello I am Florence! Do you have any problem in stomach?" + '\n');
		T6.setFont(new Font("Roboto", Font.BOLD, 20));
		T6.setForeground(Color.BLACK);
		T6.setBackground(new Color(255, 246, 143));
		T6.setEditable(false);
		
		JScrollPane b6 = new JScrollPane(T6);
		//b2.getViewport().getView().setBackground(new Color(255, 246, 143));
		b6.setWheelScrollingEnabled(true);
		b6.setVisible(true);

		jp5.setLayout(new GridLayout(1,1));
		jp5.setBackground(new Color(255, 246, 143));
		jp5.add(b6);
		jp5.setVisible(true);

			b.addActionListener
			(
			new ActionListener() 
			{
				public void actionPerformed(ActionEvent e) 
				{
					T6.setLineWrap(true);
					T6.setWrapStyleWord(true);
					String s1[] = {"Centre of Stomach", "Left Side", "Right Side", "Lower part of the Belly", "The whole belly"};
					String s2[] = {"Few Hours", "Few Days", "Long Time", "Recently"};
					String yesNo[] = {"Yes", "No"};
					if(clk5==1) 
					{
						T6.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Where is it paining?"+'\n'
								+"1.Centre of the Stomach"+'\n'+"2.Left Side"+'\n'+"3.Right Side"+'\n'+"4.Lower part of the Belly"+'\n'+"5.The whole belly"+'\n'+'\n');
						t.setText("");	
					clk5+=1;
					}else if(clk5==2) {
						for(int y=0; y<s1.length; y+=1)
							if(y==(Integer.parseInt(t.getText())-1))
								SM6[0]=s1[y];
						
						T6.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Since how long is it paining?"+'\n'
								+"1.Few Hours"+'\n'+"2.Few Days"+'\n'+"3.Long Time"+'\n'+"4.Recently"+'\n'+'\n');
						t.setText("");
					clk5+=1;
					}else if(clk5==3) {
						for(int y=0; y<s2.length; y+=1)
							if(y==(Integer.parseInt(t.getText())-1))
								SM6[1]=s2[y];
						
						T6.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Does it hurt while you move?"+'\n'
								+"1.Yes"+'\n'+"2.No"+'\n'+'\n');
						t.setText("");
					clk5+=1;
					}else if(clk5==4) {
						for(int y=0; y<yesNo.length; y+=1)
							if(y==(Integer.parseInt(t.getText())-1))
								SM6[2]=yesNo[y];
						
						T6.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Try getting up. Does it hurt?"+'\n'
								+"1.Yes"+'\n'+"2.No"+'\n'+'\n');
						t.setText("");
					clk5+=1;
					}else if(clk5==5) {
						for(int y=0; y<yesNo.length; y+=1)
							if(y==(Integer.parseInt(t.getText())-1))
								SM6[3]=yesNo[y];
						
						T6.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Did You try any Medications?"+'\n'
								+"1.Yes"+'\n'+"2.No"+'\n'+'\n');
						t.setText("");
					clk5+=1;
					}else if(clk5==6) {
						for(int y=0; y<yesNo.length; y+=1)
							if(y==(Integer.parseInt(t.getText())-1))
								SM6[4]=yesNo[y];
						
						T6.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Do you drink water on a regular basis?"+'\n'
								+"1.Yes"+'\n'+"2.No"+'\n'+'\n');
						t.setText("");
					clk5+=1;
					}else if(clk5==7) {
						for(int y=0; y<yesNo.length; y+=1)
							if(y==(Integer.parseInt(t.getText())-1))
								SM6[5]=yesNo[y];
						
						T6.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Did you eat anything oily?"+'\n'
								 +"1.Yes"+'\n'+"2.No"+'\n'+'\n');
						t.setText("");
					clk5+=1;
					}else if(clk5==8) {
						for(int y=0; y<yesNo.length; y+=1)
							if(y==(Integer.parseInt(t.getText())-1))
								SM6[6]=yesNo[y];
						
						T6.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Are you burping?"+'\n'
								+"1.Yes"+'\n'+"2.No"+'\n'+'\n');
						t.setText("");
					clk5+=1;
					}else {
						for(int y=0; y<yesNo.length; y+=1)
							if(y==(Integer.parseInt(t.getText())-1))
								SM6[7]=yesNo[y];
						
						T6.append("You--> "+t.getText()+'\n'+'\n'+"Chatbot--> Thank you for providing information");
					flg6='#';
					}
				}
			}
			);
	SPanel.add(jp5, "S6");
	}
	void TopicSelection() 
	{
	JMenuBar mb = new JMenuBar();
		B[0] = new JButton("Appointment");
		B[1] = new JButton("Leg");
		B[2] = new JButton("Hand");
		B[3] = new JButton("Chest");
		B[4] = new JButton("Head");
		B[5] = new JButton("Stomach");
		B[6] = new JButton("Update");
		
		B[0].setForeground(Color.WHITE);
		B[1].setForeground(Color.WHITE);
		B[2].setForeground(Color.WHITE);
		B[3].setForeground(Color.WHITE);
		B[4].setForeground(Color.WHITE);
		B[5].setForeground(Color.WHITE);
		B[6].setForeground(Color.WHITE);
		
		B[0].setBackground(new Color(246, 36, 89));
		B[1].setBackground(new Color(246, 36, 89));
		B[2].setBackground(new Color(246, 36, 89));
		B[3].setBackground(new Color(246, 36, 89));
		B[4].setBackground(new Color(246, 36, 89));
		B[5].setBackground(new Color(246, 36, 89));
		B[6].setBackground(Color.BLUE);
		
		B[0].setFont(new Font("Century Schoolbook", Font.ITALIC, 19));
		B[1].setFont(new Font("Century Schoolbook", Font.ITALIC, 19));
		B[2].setFont(new Font("Century Schoolbook", Font.ITALIC, 19));
		B[3].setFont(new Font("Century Schoolbook", Font.ITALIC, 19));
		B[4].setFont(new Font("Century Schoolbook", Font.ITALIC, 19));
		B[5].setFont(new Font("Century Schoolbook", Font.ITALIC, 19));
		B[6].setFont(new Font("Century Schoolbook", Font.ITALIC, 19));
		
		B[0].setContentAreaFilled(true);
		B[1].setContentAreaFilled(true);
		B[2].setContentAreaFilled(true);
		B[3].setContentAreaFilled(true);
		B[4].setContentAreaFilled(true);
		B[5].setContentAreaFilled(true);
		B[6].setContentAreaFilled(true);
		
		//LineBorder LB = new LineBorder(Color.PINK, 1, true);
		mb.setBackground(new Color(246, 36, 89));
		mb.setPreferredSize(new Dimension(250, 400));
		for(int i=0; i<7; i+=1)
			B[i].setBorder(null);
		
		mb.setLayout(new GridLayout(7, 1));
		for(int k=0; k<7; k+=1) 
			mb.add(B[k]);
		
		mb.setBorder(null);
		j.add(mb);
		
		ChatBot.Introduce_Part();
		B[0].addActionListener(
				new ActionListener() 
				{
					public void actionPerformed(ActionEvent e)
					{
						if(isRmv=='\0' && flg=='T') 
						{
							js.remove(ji);
						js.add(SPanel, BorderLayout.CENTER);
						
						c1=0;
						ChatBot.MessageBox_1();
						card.show(SPanel, "S1");
						js.validate();
						isRmv='Y';		flg='F';
						}else if(hold1=='T') {
						c1=0;
						ChatBot.MessageBox_1();
						card.show(SPanel, "S1");	hold1='F';
						}
						if(flg0=='#') {
							card.show(SPanel, "S1");
							T.setText("ChatBot--> Hello I am Florence! How can I help you?"+'\n');
							c1=0;	flg0='*';
						}hold5='T'; hold4='T'; hold2='T'; hold3='T'; hold6='T';
					
					}
				}
				);
		B[1].addActionListener(
				new ActionListener() 
				{
					public void actionPerformed(ActionEvent e)
					{
						if(isRmv=='\0' && flg=='T') 
						{
							js.remove(ji);
						js.add(SPanel, BorderLayout.CENTER);
						
						k=1;
						ChatBot.MessageBox_2();
						card.show(SPanel, "S2");
						js.validate();
						isRmv='Y';		flg='F';
						}else if(hold2=='T') {
							k=1;
						ChatBot.MessageBox_2();
						card.show(SPanel, "S2");	hold2='F';
						}
						if(flg2=='#') {
							card.show(SPanel, "S2");
							T2.setText("ChatBot--> Hello I am Florence! Do you have any leg problem?"+'\n');
							k=1;	flg2='*';
						}hold5='T'; hold4='T'; hold6='T'; hold3='T'; hold1='T';
					}
				}
				);
		B[2].addActionListener(
				new ActionListener() 
				{
					public void actionPerformed(ActionEvent e)
					{
						if(isRmv=='\0' && flg=='T') 
						{
							js.remove(ji);
						js.add(SPanel, BorderLayout.CENTER);
						
						clk2=1;
						ChatBot.MessageBox_3();
						card.show(SPanel, "S3");
						js.validate();	
						isRmv='Y';		flg='F';
						}else if(hold3=='T') {
						clk2=1;
						ChatBot.MessageBox_3();
						card.show(SPanel, "S3");
						hold3='F';
						}	
						if(flg3=='#') {
							card.show(SPanel, "S3");
							T3.setText("ChatBot--> Hello I am Florence! Do you have any problem in hand?"+'\n');
							clk2=1;		flg3='*';
						}hold5='T'; hold4='T'; hold6='T'; hold2='T'; hold1='T';
					}
				}
				);
		B[3].addActionListener
		(
				new ActionListener() 
				{
					public void actionPerformed(ActionEvent e)
					{
						if(isRmv=='\0' && flg=='T') 
						{
							js.remove(ji);
						js.add(SPanel, BorderLayout.CENTER);
						
						clk3=1;
						ChatBot.MessageBox_4();
						card.show(SPanel, "S4");
						js.validate();	
						isRmv='Y';		flg='F';
						}else if(hold4=='T') {
						clk3=1;
						ChatBot.MessageBox_4();
						card.show(SPanel, "S4");
						hold4='F';
						}	
						if(flg4=='#') {
							card.show(SPanel, "S4");
							T4.setText("ChatBot--> Hello I am Florence! Do you have any problem in chest?"+'\n');
							clk3=1;		flg4='*';
						}hold5='T'; hold6='T'; hold2='T'; hold3='T'; hold1='T';
					}
				}
		);
		B[4].addActionListener
		(
			new ActionListener() 
			{
				public void actionPerformed(ActionEvent E) 
				{
					if(isRmv=='\0' && flg=='T') 
					{
						js.remove(ji);
					js.add(SPanel, BorderLayout.CENTER);
					
					clk4=1;
					ChatBot.MessageBox_5();
					card.show(SPanel, "S5");
					js.validate();	
					isRmv='Y';		flg='F';
					}else if(hold5=='T') {
					clk4=1;
					ChatBot.MessageBox_5();
					card.show(SPanel, "S5");
					hold5='F';
					}	
					if(flg5=='#') {
						card.show(SPanel, "S5");
						T5.setText("ChatBot--> Hello I am Florence! Do you have any problem in head?"+'\n');
						clk4=1;		flg5='*';
					}hold6='T'; hold4='T'; hold2='T'; hold3='T'; hold1='T';
				}
			}
		);
		B[5].addActionListener
		(
			new ActionListener()
			{
				public void actionPerformed(ActionEvent E) 
				{
					if(isRmv=='\0' && flg=='T') 
					{
						js.remove(ji);
					js.add(SPanel, BorderLayout.CENTER);
					
					clk5=1;
					ChatBot.MessageBox_6();
					card.show(SPanel, "S6");
					js.validate();	
					isRmv='Y';		flg='F';
					}else if(hold6=='T') {
					clk5=1;
					ChatBot.MessageBox_6();
					card.show(SPanel, "S6");
					hold6='F';
					}	
					if(flg6=='#') {
						card.show(SPanel, "S6");
						T6.setText("ChatBot--> Hello I am Florence! Do you have any problem in Stomach?"+'\n');
						clk5=1;		flg6='*';
					}hold5='T'; hold4='T'; hold2='T'; hold3='T'; hold1='T';
				}
			}
		);
	}
	static void Access_Email() 
	{
		final String toEmail = JOptionPane.showInputDialog(null, "Enter Email ID ");
		final String fromEmail = "mahinmustafizsami@gmail.com"; 	//requires valid gmail id
		final String App_password = "Nrugtswkiahksnsf"; 	// correct password for gmail id 
		
		if(toEmail==null) {
			JOptionPane.showMessageDialog(null, "<html><body><h2>"
					+ "<font face=consolas color=blue>"
					+ "Your Email Is Empty! Try Again"
					+ "</font></h2></body></html>");
		}else {
			System.out.println("TLS Email Start");
			Properties props = new Properties();
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.ssl.protocols", "TLSv1.2");
			props.put("mail.smtp.starttls.enable", "true");
	        //props.put("mail.smtp.ssl.trust", "smtp.gmail.com");
			props.put("mail.smtp.host", "smtp.gmail.com");
			props.put("mail.smtp.port", "587");
			
	                //create Authenticator object to pass in Session.getInstance argument
			Authenticator auth = new Authenticator() {
				//override the getPasswordAuthentication method
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(fromEmail, App_password);
				}
			};
			Session session = Session.getInstance(props, auth);
			session.setDebug(true);
			
			try {
	        	// Create a default MimeMessage object.
	            MimeMessage message = new MimeMessage(session);

	            // Set From: header field of the header.
	            message.setFrom(new InternetAddress(fromEmail));

	            // Set To: header field of the header.
	            message.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmail));

	            // Set Subject: header field
	            message.setSubject("Patient Need An Immediate Respose");

	            // Now set the actual message
	            message.setText("Hello There, "
	            +"I am a Virtual Assistant!"+'\n'
	            +"Patient Need Your Immediate Response"+'\n'
	            +"Since, He is facing many obstacles and urgently need your help"+'\n'
	            +"Please, provide relevant resources to patient for treatment"+'\n'
	            +'\n'+'\n'+'\n'+'\n'+'\n'+'\n'
	            +"Virtual Assistant,"+'\n'
	            +"Florence");
	            System.out.println("Sending........");
	            // Send message
	            Transport.send(message);
	            System.out.println("Sent message successfully....");
	        } catch (MessagingException mex) {
	            System.out.println("ExceptionMessage: "+mex.getMessage());
	        	JOptionPane.showMessageDialog(null, "May Be Your Email Is Wrong! Try Again");
	            //throw new RuntimeException(mex);
	        }
		}
	}
	static void Database_App1() 
	{
		Connection con = null;
		String assign1, assign2, assign3;
		
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/medical_assistant","root","");
			Statement smt = con.createStatement();
			ResultSet Query = smt.executeQuery("select Name, Visiting_Hours, Room_Number from doctor where ID='M6395874'");
			while(Query.next()) {
				assign1 = new String(Query.getString(1));
				assign2 = new String(Query.getString(2));
				assign3 = new String(Query.getString(3));
			JOptionPane.showMessageDialog(null, "<html><body><h2>"
					+ "<font face=consolas color=blue>"
					+"Hospital: Square Hospital"
					+ "</font></h2></body></html>"
					+'\n'+ "Doctor: " + assign1
					+'\n' + "Visiting Hour: "+assign2
					+'\n' + "Room Number: "+ assign3);
			}
		con.close();
		}catch(Exception ex) 
		{
			System.out.println(ex.getMessage());
		}
	}
	protected void Full_History() 
	{
		fh = new JFrame("Patient History");
		ImageIcon img = new ImageIcon("Florence.png");
		fh.setIconImage(img.getImage());
		
		JPanel P = new JPanel();
		JLabel L1 = new JLabel("Leg", SwingConstants.CENTER),
			   L2 = new JLabel("Hand", SwingConstants.CENTER),
			   L3 = new JLabel("Chest", SwingConstants.CENTER),
			   L4 = new JLabel("Stomach", SwingConstants.CENTER);
		
		L1.setFont(new Font("Century Schoolbook", Font.ITALIC, 20));
		L2.setFont(new Font("Century Schoolbook", Font.ITALIC, 20));
		L3.setFont(new Font("Century Schoolbook", Font.ITALIC, 20));
		L4.setFont(new Font("Century Schoolbook", Font.ITALIC, 20));
		
		L1.setForeground(Color.BLACK);
		L2.setForeground(Color.BLACK);
		L3.setForeground(Color.BLACK);
		L4.setForeground(Color.BLACK);
		
		JLabel write_1[] = new JLabel[16];
		write_1[0] = new JLabel("Where is it paining?", SwingConstants.LEFT);
		write_1[1] = new JLabel(SM2[0], SwingConstants.LEFT);
		write_1[2] = new JLabel("Since how long is it paining?", SwingConstants.LEFT);
		write_1[3] = new JLabel(SM2[1], SwingConstants.LEFT);
		write_1[4] = new JLabel("Does it hurt while you move your leg?", SwingConstants.LEFT);
		write_1[5] = new JLabel(SM2[2], SwingConstants.LEFT);
		write_1[6] = new JLabel("Try touching the part where it is paining. Does it hurt?", SwingConstants.LEFT);
		write_1[7] = new JLabel(SM2[3], SwingConstants.LEFT);
		write_1[8] = new JLabel("Did You try any Medications?", SwingConstants.LEFT);
		write_1[9] = new JLabel(SM2[4], SwingConstants.LEFT);
		write_1[10] = new JLabel("Is it Swollen?", SwingConstants.LEFT);
		write_1[11] = new JLabel(SM2[5], SwingConstants.LEFT);
		write_1[12] = new JLabel("Did you get hurt there recently?", SwingConstants.LEFT);
		write_1[13] = new JLabel(SM2[6], SwingConstants.LEFT);
		write_1[14] = new JLabel("Did you do any leg workout recently?", SwingConstants.LEFT);
		write_1[15] = new JLabel(SM2[7], SwingConstants.LEFT);
		
		JLabel write_2[] = new JLabel[16];
		write_2[0] = new JLabel("Where is it paining?", SwingConstants.LEFT);
		write_2[1] = new JLabel(SM3[0], SwingConstants.LEFT);
		write_2[2] = new JLabel("Since how long is it paining?", SwingConstants.LEFT);
		write_2[3] = new JLabel(SM3[1], SwingConstants.LEFT);
		write_2[4] = new JLabel("Does it hurt while you move your hand?", SwingConstants.LEFT);
		write_2[5] = new JLabel(SM3[2], SwingConstants.LEFT);
		write_2[6] = new JLabel("Try bending your arms. Does it hurt?", SwingConstants.LEFT);
		write_2[7] = new JLabel(SM3[3], SwingConstants.LEFT);
		write_2[8] = new JLabel("Did You try any Medications?", SwingConstants.LEFT);
		write_2[9] = new JLabel(SM3[4], SwingConstants.LEFT);
		write_2[10] = new JLabel("Did you carry any heavyweights lately?", SwingConstants.LEFT);
		write_2[11] = new JLabel(SM3[5], SwingConstants.LEFT);
		write_2[12] = new JLabel("Did you ever get hurt on your head? If yes then how long ago?", SwingConstants.LEFT);
		write_2[13] = new JLabel(SM3[6], SwingConstants.LEFT);
		write_2[14] = new JLabel("Is it bleeding?", SwingConstants.LEFT);
		write_2[15] = new JLabel(SM3[7], SwingConstants.LEFT);
		
		JLabel write_3[] = new JLabel[16];
		write_3[0] = new JLabel("Where is it paining?", SwingConstants.LEFT);
		write_3[1] = new JLabel(SM4[0], SwingConstants.LEFT);
		write_3[2] = new JLabel("Since how long is it paining?", SwingConstants.LEFT);
		write_3[3] = new JLabel(SM4[1], SwingConstants.LEFT);
		write_3[4] = new JLabel("Does it hurt while you move your chest?", SwingConstants.LEFT);
		write_3[5] = new JLabel(SM4[2], SwingConstants.LEFT);
		write_3[6] = new JLabel("Try getting up. Does it hurt?", SwingConstants.LEFT);
		write_3[7] = new JLabel(SM4[3], SwingConstants.LEFT);
		write_3[8] = new JLabel("Did You try any Medications?", SwingConstants.LEFT);
		write_3[9] = new JLabel(SM4[4], SwingConstants.LEFT);
		write_3[10] = new JLabel("Do you drink water on a regular basis?", SwingConstants.LEFT);
		write_3[11] = new JLabel(SM4[5], SwingConstants.LEFT);
		write_3[12] = new JLabel("Did you ever had any heart related disease? If yes then how long ago?", SwingConstants.LEFT);
		write_3[13] = new JLabel(SM4[6], SwingConstants.LEFT);
		write_3[14] = new JLabel("Is it bleeding?", SwingConstants.LEFT);
		write_3[15] = new JLabel(SM4[7], SwingConstants.LEFT);
		
		JLabel write_4[] = new JLabel[16];
		write_4[0] = new JLabel("Where is it paining?", SwingConstants.LEFT);
		write_4[1] = new JLabel(SM6[0], SwingConstants.LEFT);
		write_4[2] = new JLabel("Since how long is it paining?", SwingConstants.LEFT);
		write_4[3] = new JLabel(SM6[1], SwingConstants.LEFT);
		write_4[4] = new JLabel("Does it hurt while you move?", SwingConstants.LEFT);
		write_4[5] = new JLabel(SM6[2], SwingConstants.LEFT);
		write_4[6] = new JLabel("Try getting up. Does it hurt?", SwingConstants.LEFT);
		write_4[7] = new JLabel(SM6[3], SwingConstants.LEFT);
		write_4[8] = new JLabel("Did You try any Medications?", SwingConstants.LEFT);
		write_4[9] = new JLabel(SM6[4], SwingConstants.LEFT);
		write_4[10] = new JLabel("Do you drink water on a regular basis?", SwingConstants.LEFT);
		write_4[11] = new JLabel(SM6[5], SwingConstants.LEFT);
		write_4[12] = new JLabel("Did you eat anything oily?", SwingConstants.LEFT);
		write_4[13] = new JLabel(SM6[6], SwingConstants.LEFT);
		write_4[14] = new JLabel("Are you burping?", SwingConstants.LEFT);
		write_4[15] = new JLabel(SM6[7], SwingConstants.LEFT);
		
		for(int k=0; k<16; k+=1) {
			write_1[k].setFont(new Font("Cambria", Font.ITALIC, 16));
			write_2[k].setFont(new Font("Cambria", Font.ITALIC, 16));
			write_3[k].setFont(new Font("Cambria", Font.ITALIC, 16));
			write_4[k].setFont(new Font("Cambria", Font.ITALIC, 16));
		}
		
		P.setPreferredSize(new Dimension(400, 900));
		P.setBackground(Color.WHITE);
		P.setLayout(new BoxLayout(P, BoxLayout.Y_AXIS));
		P.add(L1);
		for(int k=0; k<16; k+=1)
			P.add(write_1[k]);
		
		P.add(L2);
		for(int k=0; k<16; k+=1)
			P.add(write_2[k]);
		
		P.add(L3);
		for(int k=0; k<16; k+=1)
			P.add(write_3[k]);
		
		P.add(L4);
		for(int k=0; k<16; k+=1)
			P.add(write_4[k]);
		
		JScrollPane SP = new JScrollPane(P, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		fh.add(SP);
		fh.setSize(400, 400);
		fh.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		fh.setVisible(true);
		fh.setResizable(false);
		fh.setLocationRelativeTo(null);
	}
	void External_Options(String S)
	{
		JMenuBar mb = new JMenuBar();
		OP[0] = new JButton("Send Email");
		OP[1] = new JButton("Nearby Hospitals");
		OP[2] = new JButton("About Me");
		OP[3] = new JButton("History");
		OP[4] = new JButton("Exit");
		
		JLabel getText = new JLabel(S, JLabel.CENTER);
		getText.setFont(new Font("Cambria", Font.BOLD, 20));
		getText.setForeground(Color.BLACK);
		
		JButton back = new JButton("<");
		back.setFont(new Font("Consolas", Font.BOLD, 30));
		back.setHorizontalAlignment(SwingConstants.CENTER);
		back.setVerticalAlignment(SwingConstants.CENTER);
		back.setPreferredSize(new Dimension(45, 26));
		back.setBackground(new Color(25, 181, 254));
		back.setForeground(Color.BLACK);
		back.setBorder(null);
				
		back.addActionListener
		(
			new ActionListener() 
			{
				public void actionPerformed(ActionEvent E) 
				{
					glass.slide();
				}
			}
		);
		JPanel support2 = new JPanel();
		support2.setLayout(new BorderLayout());
		support2.setPreferredSize(new Dimension(259, 100));
		support2.setBackground(new Color(25, 181, 254));
		support2.add(back, BorderLayout.NORTH);
		support2.add(getText, BorderLayout.SOUTH);
		
		OP[0].setForeground(Color.BLACK);
		OP[1].setForeground(Color.BLACK);
		OP[2].setForeground(Color.BLACK);
		OP[3].setForeground(Color.BLACK);
		OP[4].setForeground(Color.BLACK);
		
		OP[0].setBackground(new Color(248, 148, 6));
		OP[1].setBackground(new Color(248, 148, 6));
		OP[2].setBackground(new Color(248, 148, 6));
		OP[3].setBackground(new Color(248, 148, 6));
		OP[4].setBackground(new Color(248, 148, 6));
		
		OP[0].setFont(new Font("Century Schoolbook", Font.ITALIC, 19));
		OP[1].setFont(new Font("Century Schoolbook", Font.ITALIC, 19));
		OP[2].setFont(new Font("Century Schoolbook", Font.ITALIC, 19));
		OP[3].setFont(new Font("Century Schoolbook", Font.ITALIC, 19));
		OP[4].setFont(new Font("Century Schoolbook", Font.ITALIC, 19));
		
		OP[0].setContentAreaFilled(true);
		OP[1].setContentAreaFilled(true);
		OP[2].setContentAreaFilled(true);
		OP[3].setContentAreaFilled(true);
		OP[4].setContentAreaFilled(true);
		
		//LineBorder LB = new LineBorder(Color.PINK, 1, true);
		mb.setBackground(new Color(255, 203, 5));
		mb.setPreferredSize(new Dimension(259, 300));
		for(int i=0; i<5; i+=1)
			OP[i].setBorder(null);
		
		mb.setLayout(new GridLayout(6, 1));
		for(int k=0; k<5; k+=1) 
			mb.add(OP[k]);
		
		OP[0].addActionListener
		(
			new ActionListener() 
			{
				public void actionPerformed(ActionEvent E) 
				{
					ChatBot.Access_Email();
				}
			}
		);
		OP[1].addActionListener
		(
			new ActionListener() 
			{
				public void actionPerformed(ActionEvent E) 
				{
					ChatBot.Database_App1();
				}
			}
		);
		OP[2].addActionListener
		(
			new ActionListener() 
			{
				public void actionPerformed(ActionEvent E) 
				{
					try{ 
					    Desktop.getDesktop().browse(
					    new URL("https://sites.google.com/ulab.edu.bd/florence/home").toURI());
					}catch(Exception e){
						JOptionPane.showMessageDialog(null, "<html><body><h2>"
								+ "<font color=blue face=Cambria>"
								+ "Sorry, URL May Be Invalid! Please Check?"
								+ "</font></h2></body></html>");
					} 
				}
			}
		);
		OP[3].addActionListener
		(
			new ActionListener() 
			{
				public void actionPerformed(ActionEvent E) 
				{
					Full_History();
				}
			}
		);
		OP[4].addActionListener
		(
			new ActionListener() 
			{
				public void actionPerformed(ActionEvent E) 
				{
					System.exit(0);
				}
			}
		);
		mb.setBorder(null);	
		glass.add(support2);
		glass.add(mb);
	}
}

public class Project
{
	static String U, P;
	public static void main(String args []) 
	{
		ChatBot.Appearance();

		Connection con1 = null;
		U = JOptionPane.showInputDialog(null, "<html><body><h2><font color=blue>"
				+ "Enter Username"
				+ "</font></h2></body></html>");
		P = JOptionPane.showInputDialog(null, "<html><body><h2><font color=blue>"
				+ "Enter Password"
				+ "</font></h2></body></html>");
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			con1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/medical_assistant","root","");
			Statement smt = con1.createStatement();
			ResultSet Query = smt.executeQuery("select Username, Password from user where Username = '"+U+"'"+" and Password = '"+P+"'");
			while(Query.next()) {
				System.out.println(Query.getString(1) + " " + Query.getString(2));
			}
		Thread.sleep(1000);
		ChatBot Bot = new ChatBot();
		Bot.TopicSelection();
		Bot.External_Options(U);
		
		con1.close();
		}catch(Exception ex) 
		{
			System.out.println(ex.getMessage());
			JOptionPane.showMessageDialog(null, "<html><body><h2><font color=blue>"
					+ "Sorry, Please Try Again For Opening Account"
					+ "</font></h2></body></html>");
		}
	}
}
