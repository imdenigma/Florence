-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 06, 2021 at 05:30 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `medical_assistant`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `User_id` varchar(50) NOT NULL,
  `doctor_id` char(8) NOT NULL,
  `Date` date DEFAULT NULL,
  `Time` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`User_id`, `doctor_id`, `Date`, `Time`) VALUES
('Ivan88', 'L8784661', '2021-05-06', '13:00:00'),
('kKia915', 'T3621482', '2021-06-02', '20:45:00'),
('yousuf1999', 'D3232149', '2021-05-11', '15:20:00'),
('maryjohn05', 'N7886321', '2021-05-23', '13:10:00'),
('kelly_5', 'D1250001', '2021-01-09', '17:15:00'),
('noahperez', 'T3621482', '2021-04-01', '19:30:00'),
('br894', 'L8784661', '2021-06-14', '12:30:00'),
('ddarkseid', 'M6395874', '2021-06-04', '16:45:00'),
('tom1992', 'D1395399', '2021-05-31', '10:15:00'),
('coolben4', 'M6395874', '2021-05-30', '18:00:00'),
('allentiera', 'N7886321', '2021-05-06', '12:15:00');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `ID` char(8) NOT NULL,
  `Name` varchar(90) DEFAULT NULL,
  `Specialization` varchar(20) DEFAULT NULL,
  `Visiting_Hours` varchar(18) DEFAULT NULL,
  `Room_Number` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`ID`, `Name`, `Specialization`, `Visiting_Hours`, `Room_Number`) VALUES
('A9514347', 'Dr.Jeniffer Winston', 'Dermatologist', '18:00-22:00', 'C221'),
('D1250001', 'Dr.Clyde Arias', 'Neurologist', '14:00-19:00', 'D339'),
('D1395399', 'Dr.Henry Christopher', 'Neurologist', '08:00-13:00', 'B421'),
('D3232149', 'Dr.Francis Thomas', 'Family Medicine', '10:00-16:00', 'A009'),
('L8784661', 'Dr.Stan Dupp', 'Dietitian', '11:00-16:00', 'A444'),
('M6395874', 'Dr.Johana Timm', 'Family Medicine', '17:00-22:00', 'A366'),
('N7886321', 'Dr.Derek Hasting', 'Psychologist', '09:00-14:00', 'B014'),
('R1225687', 'Dr.Paula Eastwind', 'Pathologist', '16:00-21:00', 'D748'),
('R9991324', 'Dr.Paul Ryte', 'Pathologist', '15:30-21:45', 'C044'),
('T3621482', 'Dr.Anne Ortha', 'Gynecologist', '18:00-22:00', 'B231');

-- --------------------------------------------------------

--
-- Table structure for table `health_professionals`
--

CREATE TABLE `health_professionals` (
  `ID` char(8) NOT NULL,
  `NAME` varchar(100) DEFAULT NULL,
  `Designation` varchar(80) DEFAULT NULL,
  `Time_Shift` varchar(80) DEFAULT NULL,
  `OFF_Days` varchar(30) DEFAULT NULL,
  `Phone_Number` char(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `health_professionals`
--

INSERT INTO `health_professionals` (`ID`, `NAME`, `Designation`, `Time_Shift`, `OFF_Days`, `Phone_Number`) VALUES
('02414559', 'Mary Moises', 'Phlebotomist', '10:00-15:00', 'Friday', '01155516685'),
('02441231', 'Jayden Rodri', 'Phlebotomist', '10:00-15:00', 'Saturday', '01694715647'),
('02456221', 'Saul Goodmate', 'Phlebotomist', '15:00-20:00', 'Monday', '01655511897'),
('02481254', 'Ela Singh', 'Nurse', '15:00-20:00', 'Friday', '01964127832'),
('36519154', 'Jeffry Emerson', 'Nurse', '15:00-21:00', 'Sunday', '01259556673'),
('36541121', 'Con Tsar', 'Nurse', '08:00-14:00', 'Wednesday', '01755556207'),
('98241231', 'James Silva', 'Radiographer', '10:00-15:00', 'Thursday', '01334455647'),
('98456488', 'Luis Alberto', 'Radiographer', '15:00-20:00', 'Tuesday', '01955588841'),
('98470101', 'Reeve Blue', 'Radiographer', '10:00-15:00', 'Saturday', '01579874041');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `user_id` varchar(50) NOT NULL,
  `Password` varchar(200) NOT NULL,
  `Phone_No` char(11) DEFAULT NULL,
  `Last_Login` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`user_id`, `Password`, `Phone_No`, `Last_Login`) VALUES
('Ivan88', 'iphone4swhite', '01922567411', '12 days ago'),
('kelly_5', '0189tickkelly', '01893214752', '10 minutes ago'),
('coolben4', 'icecream255', '01777778921', '6 months ago'),
('maryjohn05', 'mary8211', '01446168211', 'Online Now'),
('yousuf1999', '#211@pass98', '01844523636', '12 days ago'),
('kKia915', 'messiismyidol', '01312378945', '5 days ago'),
('allentiera', 'allenlovestieraforever', '01215449730', '41 minutes ago'),
('noahperez', 'portugalforever', '01055447366', 'Online now'),
('tom1992', 'tomcat345', '01694712345', '15 hours ago'),
('kingsam', 'sammyqwerty99', '01415161731', '24 hrs ago'),
('imdenigma', '#/1212jo@nmemo', '01299547841', 'Account Unverified'),
('br894', 'password', '01015217894', 'Online now'),
('johnoah', 'gmail.com', '01234512780', '2 years ago'),
('ddarkseid', 'bluewindows07', '01322287147', '31 minutes ago');

-- --------------------------------------------------------

--
-- Table structure for table `patient_history`
--

CREATE TABLE `patient_history` (
  `Patient_Number` varchar(80) NOT NULL,
  `Patient_ID` varchar(50) DEFAULT NULL,
  `Doctor_Consulted` char(8) DEFAULT NULL,
  `Prescription` varchar(15) DEFAULT NULL,
  `Reports` char(7) DEFAULT NULL,
  `Medications` char(6) DEFAULT NULL,
  `Symptoms` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patient_history`
--

INSERT INTO `patient_history` (`Patient_Number`, `Patient_ID`, `Doctor_Consulted`, `Prescription`, `Reports`, `Medications`, `Symptoms`) VALUES
('A144', 'Ivan88', 'L8784661', 'AD1395', 'E958714', 'M98711', 'High presence of cholestrol and Nicotin in blood sample'),
('A488', 'maryjohn05', 'N7886321', 'TG8744', 'G985412', 'B35416', 'Fear of workload and phobia'),
('A745', 'ddarkseid', 'M6395874', 'NC1212', 'A774125', 'S41015', 'Fungal infection from unidentified pollen spores. Observation required. Sample collected'),
('C236', 'kKia915', 'T3621482', 'FT6357', 'G194785', 'A78709', 'Light patches around stomach, common at this stage'),
('D144', 'tom1992', 'D1395399', 'AD9912', 'B127482', 'N31530', 'Blood not clear, random temporary blood clots in arteries.'),
('D991', 'yousuf1999', 'D3232149', 'YG7985', 'G125771', 'E17710', 'High presence of nikotin, cause of minor lung-infection'),
('K251', 'kelly_5', 'D1250001', 'DR1474', 'A366211', 'D96408', 'Dark multiple dots around Cerebellum and Migrane'),
('N326', 'coolben4', 'M6395874', 'NC9965', 'N121466', 'D31315', 'Severe Kidney infection due to stones in kidneys. Operation required ASAP'),
('R477', 'allentiera', 'N7886321', 'TG1002', 'H652158', 'A19214', 'Depression and high-stress from workload'),
('S362', 'br894', 'L8784661', 'RX2142', 'X321195', 'N71015', 'Weight loss due to stress. Need proper rest'),
('S921', 'noahperez', 'T3621482', 'FT7899', 'A321355', 'D65610', 'Stomach Upset from oil-rich food');

-- --------------------------------------------------------

--
-- Table structure for table `pharmacists`
--

CREATE TABLE `pharmacists` (
  `ID` char(7) NOT NULL,
  `NAME` varchar(200) DEFAULT NULL,
  `Time_Shift` varchar(50) DEFAULT NULL,
  `OFF_Days` varchar(25) DEFAULT NULL,
  `Phone_Number` char(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pharmacists`
--

INSERT INTO `pharmacists` (`ID`, `NAME`, `Time_Shift`, `OFF_Days`, `Phone_Number`) VALUES
('1247859', 'Elia Hartwig', '00:00-06:00', 'Friday', '01085545305'),
('1472511', 'Thomas Alaves', '12:00-18:00', 'Saturday', '01005741988'),
('1776321', 'Mousa Ali', '12:00-18:00', 'Tuesday', '01132001478'),
('1845122', 'Irwin Rennes', '00:00-06:00', 'Friday', '01000369874'),
('2135447', 'Mikel Rank', '06:00-12:00', 'Tuesday', '01225546389'),
('2144321', 'Lynetta Priolo', '06:00-12:00', 'Thursday', '01756214792'),
('2321457', 'Ellen Viera', '06:00-12:00', 'Saturday', '01987142566'),
('3224551', 'Frank Rudiger', '12:00-18:00', 'Sunday', '01113698751'),
('5552119', 'Merrie Moris', '12:00-18:00', 'Wednesday', '01981475231'),
('8336595', 'Vance Hartt', '00:00-06:00', 'Monday', '01055555554'),
('8584129', 'Shivam Singh', '06:00-12:00', 'Monday,Saturday', '01057412621');

-- --------------------------------------------------------

--
-- Table structure for table `pharmacy`
--

CREATE TABLE `pharmacy` (
  `Order_ID` char(6) NOT NULL,
  `Medicine1` varchar(80) DEFAULT NULL,
  `Phone_No` char(11) DEFAULT NULL,
  `Doctor` char(8) DEFAULT NULL,
  `Pickup_Time` varchar(25) DEFAULT NULL,
  `Pharmacist` char(7) DEFAULT NULL,
  `Medicine2` varchar(80) DEFAULT NULL,
  `Medicine3` varchar(80) DEFAULT NULL,
  `Medicine4` varchar(80) DEFAULT NULL,
  `Medicine5` varchar(80) DEFAULT NULL,
  `recipient` varchar(50) DEFAULT NULL,
  `total_amount` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pharmacy`
--

INSERT INTO `pharmacy` (`Order_ID`, `Medicine1`, `Phone_No`, `Doctor`, `Pickup_Time`, `Pharmacist`, `Medicine2`, `Medicine3`, `Medicine4`, `Medicine5`, `recipient`, `total_amount`) VALUES
('A19214', 'Becloside Abatazone', '01215449730', 'N7886321', '31/5/21(14:00)', '5552119', 'Aminex', 'Serosate', 'Pentozole', '', 'allentiera', '849'),
('A78709', 'Zonilan', '01312378945', 'T3621482', '29/5/21(09:00)', '2144321', 'Monoline', 'Sanctufinil', '', '', 'kKia915', '447'),
('B35416', 'Levospan Dorzoformin', '01446168211', 'N7886321', '25/5/21(16:00)', '5552119', 'Monoline', 'Sanctufinil', 'Capophine Olsanogen', '', 'maryjohn05', '311'),
('D31315', 'Somtoxiditan', '01777778921', 'M6395874', '31/05/21(13:15)', '3224551', 'Artebutazone', 'Sulfaikin', '', '', 'coolben4', '748'),
('D65610', 'Gerospan Dorzoformin', '01055447366', 'T3621482', '28/5/21(10:00)', '2144321', 'Capophine Olsanogen', '', '', '', 'noahperez', '201'),
('D96408', 'Paracetamol', '01893214752', 'D1250001', '31/5/21(08:00)', '2135447', 'Tributrol Symbucil', 'Acnavir', 'Retridivir', 'Afiramine', 'kelly_5', '1217'),
('E17710', 'Choriorolac', '01844523636', 'D3232149', '28/5/21(14:00)', '5552119', 'Serosate', 'Jentamicin', '', '', 'yousuf1999', '315'),
('M98711', 'Alogbital', '01922567411', 'L8784661', '28/5/21(11:00)', '2135447', 'Sevotecan', 'Evotasol', '', '', 'Ivan88', '672'),
('N31530', 'Hexanol', '01694712345', 'D1395399', '01/06/21(15:30)', '1776321', 'Tylenol', 'Excedrin', 'Naproxen', '', 'tom1992', '499'),
('N71015', 'Estripitant', '01015217894', 'L8784661', '15/06/21(10:15)', '2135447', 'Driptino', '', '', '', 'br894', '477'),
('S41015', 'Somtegriprinim', '01322287147', 'M6395874', '05/06/21(10:15)', '8584129', 'Predivir', 'Ioicaine', 'Virarestatifetamine', 'Paracetamol', 'ddarkseid', '1375');

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--

CREATE TABLE `prescription` (
  `Prescription_Number` varchar(15) NOT NULL,
  `Medicine1` varchar(100) DEFAULT NULL,
  `Medicine2` varchar(100) DEFAULT NULL,
  `Medicine3` varchar(100) DEFAULT NULL,
  `Medicine4` varchar(100) DEFAULT NULL,
  `Medicine5` varchar(100) DEFAULT NULL,
  `Doctor` char(8) DEFAULT NULL,
  `Signature` varchar(150) DEFAULT NULL,
  `Follow_Up` date DEFAULT NULL,
  `Username` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `prescription`
--

INSERT INTO `prescription` (`Prescription_Number`, `Medicine1`, `Medicine2`, `Medicine3`, `Medicine4`, `Medicine5`, `Doctor`, `Signature`, `Follow_Up`, `Username`) VALUES
('AD1395', 'Alogbital(X3*4)', 'Sevotecan(X2*2)', 'Evotasol(X1*5)', '', '', 'L8784661', 'Stan Dupp', '2021-07-21', 'Ivan88'),
('AD9912', 'Hexanol(X2*5)', 'Tylenol(X1*5)', 'Excedrin(X3*1)', 'Naproxen(X7*2)', '', 'D1395399', 'Henry Christopher', '2021-12-02', 'tom1992'),
('DR1474', 'Paracetamol(X1*3)', 'Tributrol Symbucil(X3*1)', 'Acnavir(X2*9)', 'Retridivir(X3*10)', 'Afiramine(X2*18)', 'D1250001', 'Clyde Arias', '2022-01-10', 'kelly_5'),
('FT6357', 'Zonilan(X2*1)', 'Monoline(X3*3)', 'Sanctufinil(X1*10)', 'Capophine Olsanogen(X3*10)', '', 'T3621482', 'Anne Ortha', '2022-01-02', 'kKia915'),
('FT7899', 'Gerospan Dorzoformin(X1*3)', 'Capophine Olsanogen(X3*5)', '', '', '', 'T3621482', 'Anne Ortha', '2021-10-05', 'noahperez'),
('NC1212', 'Somtegriprinim(X3*1)', 'Predivir(X5*5)', 'Ioicaine(X3*2)', 'Virarestatifetamine(X5*2)', 'Paracetamol(if pain)', 'M6395874', 'Johanna Timm', '2021-07-15', 'ddarkseid'),
('NC9965', 'Somtoxiditan(X7*2)', 'Artebutazone(X6*1)', 'Sulfaikin(X3*3)', '', '', 'M6395874', 'Johanna Timm', '2021-06-15', 'coolben4'),
('RX2142', 'Estripitant(X4*2)', 'Driptino(X6*1)', '', '', '', 'L8784661', 'Stan Dupp', '2021-06-15', 'br894'),
('TG1002', 'Becloside Abatazone(X1*10)', 'Aminex(X5*3)', 'Serosate(X2*4)', 'Pentozole(X1*4)', '', 'N7886321', 'Derek Hasting', '2021-06-02', 'allentiera'),
('TG8744', 'Levospan Dorzoformin(X1*5)', 'Serosate(X2*4)', 'Jentamicin(X2*5)', '', '', 'N7886321', 'Derek Hasting', '2021-06-12', 'maryjohn05'),
('YG7985', 'Choriorolac(X3*5)', '', '', '', '', 'D3232149', 'Francis Thomas', '2021-06-02', 'yousuf1999');

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `Report_ID` char(7) NOT NULL,
  `Room_Number` char(4) DEFAULT NULL,
  `Results` varchar(150) DEFAULT NULL,
  `User` varchar(50) NOT NULL,
  `Doctor_Consulted` char(8) NOT NULL,
  `Symptoms` varchar(100) DEFAULT NULL,
  `Staff_On_Duty` char(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`Report_ID`, `Room_Number`, `Results`, `User`, `Doctor_Consulted`, `Symptoms`, `Staff_On_Duty`) VALUES
('A321355', 'A355', 'Negative', 'noahperez', 'T3621482', 'No Symptoms', '98456488'),
('A366211', 'A211', 'Positive', 'kelly_5', 'D1250001', 'Dark multiple dots around Cerebellum', '98456488'),
('A774125', 'C125', 'Positive', 'ddarkseid', 'M6395874', 'infection on right hand, clear syymptom of fungal infection', '02456221'),
('B127482', 'A482', 'Positive', 'tom1992', 'D1395399', 'blood not clear, presence of pb and high amount of Nacl', '02481254'),
('E958714', 'E714', 'Positive', 'Ivan88', 'L8784661', 'High presence of cholestrol and Nicotin in blood sample', '02414559'),
('G125771', 'G771', 'Positive', 'yousuf1999', 'D3232149', 'High presence of nikotin, cause of infection', '02456221'),
('G194785', 'G785', 'Negative', 'kKia915', 'T3621482', 'Light patches around stomach', '98470101'),
('G985412', 'G412', 'Negative', 'maryjohn05', 'N7886321', 'No major symptoms', '36519154'),
('H652158', 'H158', 'Negative', 'allentiera', 'N7886321', 'No symptoms', '98470101'),
('N121466', 'A466', 'Positive', 'coolben4', 'M6395874', 'Presence of stones in kidneys ', '98241231'),
('X321195', 'C195', 'Negative', 'br894', 'L8784661', 'No Symptoms', '98241231');

-- --------------------------------------------------------

--
-- Table structure for table `symptoms`
--

CREATE TABLE `symptoms` (
  `User_ID` char(7) NOT NULL,
  `Pain_Area` varchar(40) DEFAULT NULL,
  `D_Pain_Area` varchar(40) DEFAULT NULL,
  `Pain_time` varchar(40) DEFAULT NULL,
  `H_Movement` varchar(40) DEFAULT NULL,
  `H_Touch` varchar(40) DEFAULT NULL,
  `Medication` varchar(40) DEFAULT NULL,
  `Swollen` varchar(40) DEFAULT NULL,
  `Recent_Hurt` varchar(40) DEFAULT NULL,
  `Disease_heavyload` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `Username` varchar(50) NOT NULL,
  `First_Name` varchar(70) DEFAULT NULL,
  `Surname` varchar(70) DEFAULT NULL,
  `Gender` char(1) DEFAULT NULL,
  `Blood_Group` varchar(8) DEFAULT NULL,
  `Phone_Number` char(11) DEFAULT NULL,
  `Password` varchar(200) DEFAULT NULL,
  `AGE` int(11) DEFAULT NULL,
  `WEIGHT` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`Username`, `First_Name`, `Surname`, `Gender`, `Blood_Group`, `Phone_Number`, `Password`, `AGE`, `WEIGHT`) VALUES
('allentiera', 'Allen', 'Tiera', 'F', 'B-ve', '01215449730', 'allenlovestieraforever', 16, 48),
('br894', 'Brendon', 'Robson', 'M', 'AB-ve', '01015217894', 'password', 63, 45),
('coolben4', 'Ben', 'Annon', 'M', 'A-ve', '01777778921', 'icecream255', 65, 97),
('ddarkseid', 'Wilfred', 'Passington', 'M', 'O-ve', '01322287147', 'bluewindows07', 19, 81),
('imdenigma', 'John', 'Rogers', 'M', 'B-ve', '01299547841', '#/1212jo@nmemo', 35, 73),
('Ivan88', 'Ivan', 'Santos', 'M', 'AB+ve', '01922567411', 'iphone4swhite', 45, 119),
('johnoah', 'Joan', 'Dest', 'F', 'AB-ve', '01234512780', 'gmail.com', 45, 87),
('kelly_5', 'Kelly', 'Tick', 'F', 'A+ve', '01893214752', '0189tickkelly', 26, 74),
('kingsam', 'Antonine', 'Mcckeny', 'M', 'O+ve', '01415161731', 'sammyqwerty99', 18, 98),
('kKia915', 'Kia', 'Twishes', 'F', 'B+ve', '01312378945', 'messiismyidol', 39, 68),
('maryjohn05', 'Mary', 'Abraham', 'F', 'B+ve', '01446168211', 'mary8211', 53, 105),
('noahperez', 'Lia', 'Zynah', 'F', 'AB+ve', '01055447366', 'portugalforever', 66, 74),
('tom1992', 'Thomas', 'Rodryo', 'M', 'AB+ve', '01694712345', 'tomcat345', 21, 72),
('yousuf1999', 'Yousuf', 'Domino', 'M', 'O+ve', '01844523636', '#211@pass98', 31, 79);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD KEY `doctor_id` (`doctor_id`),
  ADD KEY `User_id` (`User_id`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `health_professionals`
--
ALTER TABLE `health_professionals`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `Phone_Number` (`Phone_Number`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD KEY `user_id` (`user_id`),
  ADD KEY `Phone_No` (`Phone_No`);

--
-- Indexes for table `patient_history`
--
ALTER TABLE `patient_history`
  ADD PRIMARY KEY (`Patient_Number`),
  ADD KEY `Patient_ID` (`Patient_ID`),
  ADD KEY `Doctor_Consulted` (`Doctor_Consulted`),
  ADD KEY `Prescription` (`Prescription`),
  ADD KEY `Reports` (`Reports`),
  ADD KEY `Medications` (`Medications`);

--
-- Indexes for table `pharmacists`
--
ALTER TABLE `pharmacists`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `Phone_Number` (`Phone_Number`);

--
-- Indexes for table `pharmacy`
--
ALTER TABLE `pharmacy`
  ADD PRIMARY KEY (`Order_ID`),
  ADD KEY `Doctor` (`Doctor`),
  ADD KEY `Pharmacist` (`Pharmacist`),
  ADD KEY `Phone_No` (`Phone_No`),
  ADD KEY `recipient` (`recipient`);

--
-- Indexes for table `prescription`
--
ALTER TABLE `prescription`
  ADD PRIMARY KEY (`Prescription_Number`),
  ADD KEY `Doctor` (`Doctor`),
  ADD KEY `Username` (`Username`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`Report_ID`),
  ADD KEY `User` (`User`),
  ADD KEY `Doctor_Consulted` (`Doctor_Consulted`),
  ADD KEY `Staff_On_Duty` (`Staff_On_Duty`);

--
-- Indexes for table `symptoms`
--
ALTER TABLE `symptoms`
  ADD PRIMARY KEY (`User_ID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`Username`),
  ADD UNIQUE KEY `Phone_Number` (`Phone_Number`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`doctor_id`) REFERENCES `doctor` (`ID`),
  ADD CONSTRAINT `appointments_ibfk_2` FOREIGN KEY (`User_id`) REFERENCES `user` (`Username`);

--
-- Constraints for table `login`
--
ALTER TABLE `login`
  ADD CONSTRAINT `login_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`Username`),
  ADD CONSTRAINT `login_ibfk_2` FOREIGN KEY (`Phone_No`) REFERENCES `user` (`Phone_Number`);

--
-- Constraints for table `patient_history`
--
ALTER TABLE `patient_history`
  ADD CONSTRAINT `patient_history_ibfk_1` FOREIGN KEY (`Patient_ID`) REFERENCES `user` (`Username`),
  ADD CONSTRAINT `patient_history_ibfk_2` FOREIGN KEY (`Doctor_Consulted`) REFERENCES `doctor` (`ID`),
  ADD CONSTRAINT `patient_history_ibfk_3` FOREIGN KEY (`Prescription`) REFERENCES `prescription` (`Prescription_Number`),
  ADD CONSTRAINT `patient_history_ibfk_4` FOREIGN KEY (`Reports`) REFERENCES `report` (`Report_ID`),
  ADD CONSTRAINT `patient_history_ibfk_5` FOREIGN KEY (`Medications`) REFERENCES `pharmacy` (`Order_ID`);

--
-- Constraints for table `pharmacy`
--
ALTER TABLE `pharmacy`
  ADD CONSTRAINT `pharmacy_ibfk_1` FOREIGN KEY (`Doctor`) REFERENCES `doctor` (`ID`),
  ADD CONSTRAINT `pharmacy_ibfk_2` FOREIGN KEY (`Pharmacist`) REFERENCES `pharmacists` (`ID`),
  ADD CONSTRAINT `pharmacy_ibfk_3` FOREIGN KEY (`Phone_No`) REFERENCES `user` (`Phone_Number`),
  ADD CONSTRAINT `pharmacy_ibfk_4` FOREIGN KEY (`recipient`) REFERENCES `user` (`Username`);

--
-- Constraints for table `prescription`
--
ALTER TABLE `prescription`
  ADD CONSTRAINT `prescription_ibfk_1` FOREIGN KEY (`Doctor`) REFERENCES `doctor` (`ID`),
  ADD CONSTRAINT `prescription_ibfk_2` FOREIGN KEY (`Username`) REFERENCES `user` (`Username`);

--
-- Constraints for table `report`
--
ALTER TABLE `report`
  ADD CONSTRAINT `report_ibfk_1` FOREIGN KEY (`User`) REFERENCES `user` (`Username`),
  ADD CONSTRAINT `report_ibfk_2` FOREIGN KEY (`Doctor_Consulted`) REFERENCES `doctor` (`ID`),
  ADD CONSTRAINT `report_ibfk_3` FOREIGN KEY (`Staff_On_Duty`) REFERENCES `health_professionals` (`ID`);

--
-- Constraints for table `symptoms`
--
ALTER TABLE `symptoms`
  ADD CONSTRAINT `symptoms_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `user` (`Username`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
